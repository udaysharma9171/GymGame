import express from 'express';
import cors from 'cors';
import bcrypt from 'bcrypt';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Ensure data directory exists
const dataDir = path.join(__dirname, 'data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

// Initialize data files if they don't exist
const dataFiles = ['users.json', 'plans.json', 'progress.json'];
dataFiles.forEach(file => {
  const filePath = path.join(dataDir, file);
  if (!fs.existsSync(filePath)) {
    fs.writeFileSync(filePath, JSON.stringify([], null, 2));
  }
});

// Initialize express app
const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Helper functions for file-based storage
const storage = {
  readData: (file) => {
    try {
      const data = fs.readFileSync(path.join(dataDir, file), 'utf-8');
      return JSON.parse(data);
    } catch (error) {
      console.error(`Error reading ${file}:`, error);
      return [];
    }
  },
  writeData: (file, data) => {
    try {
      fs.writeFileSync(path.join(dataDir, file), JSON.stringify(data, null, 2));
      return true;
    } catch (error) {
      console.error(`Error writing to ${file}:`, error);
      return false;
    }
  }
};

// Simple authentication middleware
const authenticate = (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const token = authHeader.split(' ')[1];
  const [email] = Buffer.from(token, 'base64').toString().split(':');

  const users = storage.readData('users.json');
  const user = users.find(u => u.email === email);

  if (!user) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  req.user = user;
  next();
};

// User Routes
app.post('/api/signup', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    const users = storage.readData('users.json');
    
    // Check if user already exists
    if (users.some(user => user.email === email)) {
      return res.status(400).json({ error: 'Email already in use' });
    }
    
    // Hash password
    const saltRounds = 10;
    const passwordHash = await bcrypt.hash(password, saltRounds);
    
    // Create new user
    const newUser = {
      email,
      passwordHash,
      height: null,
      weight: null,
      goal: null,
      xp: 0,
      level: 1,
      streakCount: 0,
      lastWorkoutDate: null,
      badges: []
    };
    
    users.push(newUser);
    storage.writeData('users.json', users);
    
    // Create token (simple implementation)
    const token = Buffer.from(`${email}:${Date.now()}`).toString('base64');
    
    // Return user data (excluding password)
    const { passwordHash: _, ...userData } = newUser;
    
    res.status(201).json({ token, user: userData });
  } catch (error) {
    console.error('Signup error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    const users = storage.readData('users.json');
    const user = users.find(u => u.email === email);
    
    // Check if user exists and password matches
    if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
      return res.status(400).json({ error: 'Invalid credentials' });
    }
    
    // Create token (simple implementation)
    const token = Buffer.from(`${email}:${Date.now()}`).toString('base64');
    
    // Return user data (excluding password)
    const { passwordHash, ...userData } = user;
    
    res.json({ token, user: userData });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/profile', authenticate, (req, res) => {
  const { passwordHash, ...userData } = req.user;
  res.json(userData);
});

app.post('/api/profile', authenticate, (req, res) => {
  try {
    const { height, weight, goal } = req.body;
    
    const users = storage.readData('users.json');
    const userIndex = users.findIndex(u => u.email === req.user.email);
    
    if (userIndex === -1) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    // Update user profile
    users[userIndex] = {
      ...users[userIndex],
      height: height || users[userIndex].height,
      weight: weight || users[userIndex].weight,
      goal: goal || users[userIndex].goal
    };
    
    storage.writeData('users.json', users);
    
    // Return updated user data (excluding password)
    const { passwordHash, ...userData } = users[userIndex];
    res.json(userData);
  } catch (error) {
    console.error('Update profile error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Workout Plan Routes
app.get('/api/plan', authenticate, (req, res) => {
  try {
    const plans = storage.readData('plans.json');
    const userPlan = plans.find(p => p.email === req.user.email);
    
    if (!userPlan) {
      return res.json({ plan: [] });
    }
    
    res.json({ plan: userPlan.workouts });
  } catch (error) {
    console.error('Get plan error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/plan', authenticate, (req, res) => {
  try {
    const { height, weight, goal } = req.body;
    
    if (!height || !weight || !goal) {
      return res.status(400).json({ error: 'Missing profile information' });
    }
    
    // Calculate BMI
    const bmi = weight / (height * height);
    
    // Determine intensity based on BMI and goal
    let intensity;
    if (bmi < 18.5) {
      intensity = goal === 'bulking' ? 'Medium' : 'Low';
    } else if (bmi < 25) {
      intensity = 'Medium';
    } else {
      intensity = goal === 'cutting' ? 'High' : 'Medium';
    }
    
    // Generate workout plan
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    
    // Define exercise templates
    const exercises = {
      strength: [
        { name: 'Push-ups', reps: '3x12' },
        { name: 'Squats', reps: '3x15' },
        { name: 'Lunges', reps: '3x10 each leg' },
        { name: 'Plank', reps: '3x30 seconds' },
        { name: 'Mountain Climbers', reps: '3x20' },
        { name: 'Burpees', reps: '3x10' },
        { name: 'Tricep Dips', reps: '3x12' },
        { name: 'Glute Bridges', reps: '3x15' }
      ],
      cardio: [
        { name: 'Jumping Jacks', reps: '4x30 seconds' },
        { name: 'High Knees', reps: '4x30 seconds' },
        { name: 'Skipping', reps: '5 minutes' },
        { name: 'Burpees', reps: '3x8' }
      ],
      yoga: [
        { name: 'Downward Dog', reps: '30 seconds' },
        { name: 'Warrior Pose', reps: '30 seconds each side' },
        { name: 'Chair Pose', reps: '30 seconds' },
        { name: 'Tree Pose', reps: '30 seconds each leg' }
      ],
      meditation: [
        { name: 'Deep Breathing', reps: '5 minutes' },
        { name: 'Body Scan', reps: '10 minutes' }
      ]
    };
    
    // Generate workouts based on goal and intensity
    const workouts = days.map((day, index) => {
      let workoutType, durationMinutes, exerciseList;
      
      // Rest day on Sunday
      if (index === 6) {
        return {
          day,
          title: 'Rest & Recovery',
          duration: '15 minutes',
          intensity: 'Low',
          exercises: [
            { name: 'Light Stretching', reps: '10 minutes' },
            { name: 'Meditation', reps: '5 minutes' }
          ],
          isCompleted: false
        };
      }
      
      // Alternate workout types
      if (index % 3 === 0) {
        workoutType = 'Full Body';
        durationMinutes = intensity === 'High' ? 45 : (intensity === 'Medium' ? 35 : 25);
        exerciseList = [
          ...exercises.strength.slice(0, 4),
          ...exercises.cardio.slice(0, 2)
        ];
      } else if (index % 3 === 1) {
        workoutType = goal === 'bulking' ? 'Upper Body Focus' : 'Cardio Blast';
        durationMinutes = intensity === 'High' ? 40 : (intensity === 'Medium' ? 30 : 20);
        exerciseList = goal === 'bulking' 
          ? [...exercises.strength.slice(0, 3), ...exercises.strength.slice(5, 7)]
          : [...exercises.cardio, ...exercises.strength.slice(4, 6)];
      } else {
        workoutType = goal === 'cutting' ? 'HIIT Session' : 'Core & Flexibility';
        durationMinutes = intensity === 'High' ? 35 : (intensity === 'Medium' ? 25 : 15);
        exerciseList = goal === 'cutting'
          ? [...exercises.cardio.slice(0, 3), ...exercises.strength.slice(4, 6)]
          : [...exercises.strength.slice(3, 5), ...exercises.yoga.slice(0, 2)];
      }
      
      return {
        day,
        title: workoutType,
        duration: `${durationMinutes} minutes`,
        intensity,
        exercises: exerciseList,
        isCompleted: false
      };
    });
    
    // Save workout plan
    const plans = storage.readData('plans.json');
    const planIndex = plans.findIndex(p => p.email === req.user.email);
    
    if (planIndex === -1) {
      plans.push({
        email: req.user.email,
        workouts
      });
    } else {
      plans[planIndex].workouts = workouts;
    }
    
    storage.writeData('plans.json', plans);
    
    res.json({ plan: workouts });
  } catch (error) {
    console.error('Generate plan error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Workout Completion Route
app.post('/api/workout/complete', authenticate, (req, res) => {
  try {
    const { workoutId, workoutTitle } = req.body;
    
    // Update workout plan to mark as completed
    const plans = storage.readData('plans.json');
    const userPlan = plans.find(p => p.email === req.user.email);
    
    if (userPlan && userPlan.workouts[workoutId]) {
      userPlan.workouts[workoutId].isCompleted = true;
      storage.writeData('plans.json', plans);
    }
    
    // Calculate XP earned (between 50-120 XP per workout)
    const baseXp = 50;
    const bonusXp = Math.floor(Math.random() * 70);
    const xpEarned = baseXp + bonusXp;
    
    // Update user stats
    const users = storage.readData('users.json');
    const userIndex = users.findIndex(u => u.email === req.user.email);
    
    if (userIndex === -1) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    const currentUser = users[userIndex];
    const today = new Date().toISOString().split('T')[0];
    const lastWorkout = currentUser.lastWorkoutDate;
    
    // Calculate streak
    let newStreak = currentUser.streakCount;
    
    if (!lastWorkout) {
      // First workout ever
      newStreak = 1;
    } else if (lastWorkout === today) {
      // Already worked out today, no change to streak
    } else {
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const yesterdayString = yesterday.toISOString().split('T')[0];
      
      if (lastWorkout === yesterdayString) {
        // Consecutive day, increase streak
        newStreak += 1;
      } else {
        // Streak broken, start new streak
        newStreak = 1;
      }
    }
    
    // Update XP and check for level up
    let newXp = currentUser.xp + xpEarned;
    let newLevel = currentUser.level;
    
    // Simple leveling formula: level N requires N * 100 XP
    const xpForNextLevel = newLevel * 100;
    if (newXp >= xpForNextLevel) {
      newLevel += 1;
    }
    
    // Update user data
    users[userIndex] = {
      ...currentUser,
      xp: newXp,
      level: newLevel,
      streakCount: newStreak,
      lastWorkoutDate: today
    };
    
    storage.writeData('users.json', users);
    
    // Record progress
    const progress = storage.readData('progress.json');
    progress.push({
      email: req.user.email,
      type: 'workout',
      title: workoutTitle,
      date: today,
      xpEarned
    });
    
    storage.writeData('progress.json', progress);
    
    res.json({ 
      xpEarned, 
      newTotalXp: newXp, 
      level: newLevel, 
      streak: newStreak 
    });
  } catch (error) {
    console.error('Workout completion error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Stats Route
app.get('/api/stats', authenticate, (req, res) => {
  try {
    // Get user progress data
    const progress = storage.readData('progress.json');
    const userProgress = progress.filter(p => p.email === req.user.email);
    
    // Get user's workout plan
    const plans = storage.readData('plans.json');
    const userPlan = plans.find(p => p.email === req.user.email);
    
    // Calculate stats
    const workoutsCompleted = userProgress.filter(p => p.type === 'workout').length;
    const totalXpEarned = userProgress.reduce((sum, p) => sum + (p.xpEarned || 0), 0);
    
    // Find next workout (first uncompleted one)
    let nextWorkout = null;
    if (userPlan && userPlan.workouts) {
      const uncompleted = userPlan.workouts.find(w => !w.isCompleted);
      if (uncompleted) {
        nextWorkout = {
          title: uncompleted.title,
          day: uncompleted.day
        };
      }
    }
    
    res.json({
      workoutsCompleted,
      streakDays: req.user.streakCount || 0,
      totalXpEarned,
      nextWorkout
    });
  } catch (error) {
    console.error('Get stats error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Rewards Routes
app.get('/api/rewards', authenticate, (req, res) => {
  // In a real app, these would come from the database
  // For this demo, we'll return a hardcoded list
  const rewards = [
    {
      id: 1,
      title: 'Premium Workout Pack',
      description: 'Unlock 5 exclusive high-intensity workouts',
      xpCost: 1000,
      image: 'https://images.pexels.com/photos/2261482/pexels-photo-2261482.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
    {
      id: 2,
      title: 'Virtual Personal Trainer',
      description: 'One-on-one session with a fitness expert',
      xpCost: 2500,
      image: 'https://images.pexels.com/photos/4058411/pexels-photo-4058411.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
    {
      id: 3,
      title: 'Nutrition Guide',
      description: 'Custom meal plans to complement your workouts',
      xpCost: 1500,
      image: 'https://images.pexels.com/photos/1640773/pexels-photo-1640773.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
    {
      id: 4,
      title: 'Gold Profile Badge',
      description: 'Exclusive profile badge to show your dedication',
      xpCost: 500,
      image: 'https://images.pexels.com/photos/6111616/pexels-photo-6111616.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
    {
      id: 5,
      title: 'Meditation Pack',
      description: 'Access to premium guided meditation sessions',
      xpCost: 800,
      image: 'https://images.pexels.com/photos/3822622/pexels-photo-3822622.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
    {
      id: 6,
      title: 'Custom Workout Theme',
      description: 'Change the look and feel of your workout interface',
      xpCost: 600,
      image: 'https://images.pexels.com/photos/7676394/pexels-photo-7676394.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
  ];
  
  res.json(rewards);
});

app.post('/api/reward', authenticate, (req, res) => {
  try {
    const { rewardId } = req.body;
    
    // In a real app, fetch reward details from the database
    // For this demo, we'll use a hardcoded list
    const rewards = [
      { id: 1, title: 'Premium Workout Pack', xpCost: 1000 },
      { id: 2, title: 'Virtual Personal Trainer', xpCost: 2500 },
      { id: 3, title: 'Nutrition Guide', xpCost: 1500 },
      { id: 4, title: 'Gold Profile Badge', xpCost: 500 },
      { id: 5, title: 'Meditation Pack', xpCost: 800 },
      { id: 6, title: 'Custom Workout Theme', xpCost: 600 },
    ];
    
    const reward = rewards.find(r => r.id === rewardId);
    
    if (!reward) {
      return res.status(404).json({ error: 'Reward not found' });
    }
    
    // Check if user has enough XP
    const users = storage.readData('users.json');
    const userIndex = users.findIndex(u => u.email === req.user.email);
    
    if (userIndex === -1) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    if (users[userIndex].xp < reward.xpCost) {
      return res.status(400).json({ error: 'Not enough XP' });
    }
    
    // Deduct XP and update user
    users[userIndex].xp -= reward.xpCost;
    
    // If it's a badge reward, add it to user's badges
    if (reward.id === 4) {
      if (!users[userIndex].badges) {
        users[userIndex].badges = [];
      }
      users[userIndex].badges.push('Gold Badge');
    }
    
    storage.writeData('users.json', users);
    
    // Record transaction
    const progress = storage.readData('progress.json');
    progress.push({
      email: req.user.email,
      type: 'reward',
      title: reward.title,
      date: new Date().toISOString().split('T')[0],
      xpCost: reward.xpCost
    });
    
    storage.writeData('progress.json', progress);
    
    res.json({ 
      success: true, 
      remainingXp: users[userIndex].xp,
      reward: reward.title
    });
  } catch (error) {
    console.error('Reward purchase error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Progress Route
app.get('/api/progress', authenticate, (req, res) => {
  try {
    const progress = storage.readData('progress.json');
    const userProgress = progress.filter(p => p.email === req.user.email);
    
    // Organize by type
    const workouts = userProgress
      .filter(p => p.type === 'workout')
      .map(p => ({
        date: p.date,
        title: p.title,
        xpEarned: p.xpEarned
      }));
    
    const rewards = userProgress
      .filter(p => p.type === 'reward')
      .map(p => ({
        date: p.date,
        title: p.title,
        xpCost: p.xpCost
      }));
    
    res.json({ workouts, rewards });
  } catch (error) {
    console.error('Get progress error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});